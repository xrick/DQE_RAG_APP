#### 3.2. Chunking with Langchain and Tiktoken with a maximum of 512/1024 tokens and 25% of overlapping

Here is the link about this technique:
<https://python.langchain.com/v0.1/docs/modules/data_connection/document_transformers/split_by_token/>

**Code Snippet:**
[chunking_with_max_tokens.ipynb](./chunking_with_max_tokens.ipynb)