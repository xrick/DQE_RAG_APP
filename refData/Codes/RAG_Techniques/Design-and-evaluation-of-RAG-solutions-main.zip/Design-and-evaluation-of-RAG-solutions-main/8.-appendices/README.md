
# 8. Appendices

## 8.1. Section classification

Include as an CSV or Excel object the complete list of content classification with the process described in 2.1.2.

## 8.2. Possible duplicate documents

Include as an CSV or Excel object the complete list of possible duplicate documents with the process described in 2.1.3.

## 8.3. Synthetic Q&A pairs generated

Include as a plain text, CSV or Excel object the complete list of questions and answers generated with the process described in 5.2.
