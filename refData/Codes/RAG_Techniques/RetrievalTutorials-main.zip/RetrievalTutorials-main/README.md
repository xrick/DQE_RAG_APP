# Full Stack Retrieval

Signup for Full Stack Retrieval at [FullStackRetrieval.com](https://fullstackretrieval.com)

## Trailer

[![Full Stack Retrieval Trailer](https://img.youtube.com/vi/G9qRxnwMYaI/0.jpg)](https://www.youtube.com/watch?v=G9qRxnwMYaI)

Made with ❤️ by [Greg Kamradt](https://twitter.com/GregKamradt) and [FullStackRetrieval.com](https://fullstackretrieval.com)