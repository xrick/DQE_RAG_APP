---
description: More learning material
---

# 📚 Resources

* [Retrieval Vocabulary](retrieval-vocabulary.md) - A list of common retrieval words, slogans, and sayings along with their definitions

* **Retrieval Content** - This is a great spot to surround yourself with more information
  * [LangChain Advanced Retrieval Webinar](https://www.youtube.com/watch?v=DY3sT4yIezs)
  * [Interview with Anton (Co-Founder @ Chroma) on retrieval trends](https://www.youtube.com/watch?v=fDmQnB8Ga6g\&t=1273s)