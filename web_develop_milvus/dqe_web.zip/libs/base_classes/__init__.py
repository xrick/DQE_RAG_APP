from .baseclasses import AssistantRequest, AssistantResponse

__all__ = ['AssistantRequest', 'AssistantResponse']